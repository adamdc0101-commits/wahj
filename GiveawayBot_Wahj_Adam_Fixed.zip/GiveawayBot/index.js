require("dotenv").config();

const fs = require("node:fs");
const {
  Client,
  GatewayIntentBits,
  SlashCommandBuilder,
  REST,
  Routes,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  ChannelType,
  PermissionFlagsBits
} = require("discord.js");

const { TOKEN, CLIENT_ID, GUILD_ID } = process.env;
const CUSTOM_EMOJI = "<a:4245:1574090554554196068>";
const DATA_FILE = "./giveaways.json";

if (!TOKEN || !CLIENT_ID || !GUILD_ID) {
  console.error("Missing TOKEN, CLIENT_ID, or GUILD_ID in .env");
  process.exit(1);
}

const IMAGE_CHANNEL_ID = "1568235397526327306";
const SETTINGS_FILE = "./bot-settings.json";
const TICKETS_FILE = "./tickets.json";
const BROADCAST_FILE = "./broadcast-settings.json";
const PAYMENT_PROOF_CHANNEL_ID = "1568132595563241562";
const CREDIT_PANEL_CHANNEL_ID = "1574776544952586320";
const TICKET_CATEGORY_ID = process.env.TICKET_CATEGORY_ID || "1568117182515384412";
const STAFF_ROLE_ID = process.env.STAFF_ROLE_ID || "1568838830985977907";
const LTC_USDT_RATE = Number(process.env.LTC_USDT_RATE || 0); // عدد USDT لكل 1 LTC، يضبطه صاحب البوت من مصدر موثوق
const client = new Client({ intents: [
  GatewayIntentBits.Guilds,
  GatewayIntentBits.GuildMessages,
  GatewayIntentBits.MessageContent,
  GatewayIntentBits.GuildMembers,
  GatewayIntentBits.GuildPresences
] });

function loadSettings() {
  try {
    if (!fs.existsSync(SETTINGS_FILE)) fs.writeFileSync(SETTINGS_FILE, JSON.stringify({ autoReplies: [] }, null, 2));
    const parsed = JSON.parse(fs.readFileSync(SETTINGS_FILE, "utf8"));
    return { autoReplies: Array.isArray(parsed.autoReplies) ? parsed.autoReplies : [] };
  } catch (error) {
    console.error("Could not read bot-settings.json:", error);
    return { autoReplies: [] };
  }
}
const settings = loadSettings();
function saveSettings() {
  fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
}

// Broadcast subscriptions: only members who explicitly opted in can receive DMs.
function loadBroadcastData() {
  try {
    if (!fs.existsSync(BROADCAST_FILE)) fs.writeFileSync(BROADCAST_FILE, JSON.stringify({ subscribers: {} }, null, 2));
    const data = JSON.parse(fs.readFileSync(BROADCAST_FILE, "utf8"));
    return { subscribers: data.subscribers && typeof data.subscribers === "object" ? data.subscribers : {} };
  } catch (error) {
    console.error("Could not read broadcast-settings.json:", error);
    return { subscribers: {} };
  }
}
const broadcastData = loadBroadcastData();
function saveBroadcastData() {
  fs.writeFileSync(BROADCAST_FILE, JSON.stringify(broadcastData, null, 2));
}
function isBroadcastSubscriber(guildId, userId) {
  return broadcastData.subscribers[guildId]?.includes(userId) || false;
}
function setBroadcastSubscription(guildId, userId, enabled) {
  const current = new Set(broadcastData.subscribers[guildId] || []);
  if (enabled) current.add(userId); else current.delete(userId);
  broadcastData.subscribers[guildId] = [...current];
  saveBroadcastData();
}
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

function loadData() {
  try {
    if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, "{}");
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch (error) {
    console.error("Could not read giveaways.json:", error);
    return {};
  }
}

let giveaways = loadData();

function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(giveaways, null, 2));
}

function parseDuration(value) {
  const match = /^([1-9]\d*)(m|h|d)$/i.exec(value.trim());
  if (!match) return null;
  const amount = Number(match[1]);
  const multiplier = { m: 60_000, h: 3_600_000, d: 86_400_000 }[match[2].toLowerCase()];
  const ms = amount * multiplier;
  return Number.isSafeInteger(ms) && ms <= 30 * 86_400_000 ? ms : null;
}

const commandData = [
  new SlashCommandBuilder()
    .setName("giveaway")
    .setDescription("إنشاء جيف أوي جديد")
    .addStringOption(o => o.setName("duration").setDescription("مثال: 10m أو 2h أو 1d").setRequired(true))
    .addStringOption(o => o.setName("prize").setDescription("الجائزة").setMaxLength(200).setRequired(true))
    .addIntegerOption(o => o.setName("winners").setDescription("عدد الفائزين").setMinValue(1).setMaxValue(20).setRequired(true))
    .addStringOption(o => o.setName("title").setDescription("عنوان الجيف أوي").setMaxLength(200).setRequired(true))
    .addStringOption(o => o.setName("description").setDescription("رسالة إضافية").setMaxLength(1000).setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder()
    .setName("endgiveaway")
    .setDescription("إنهاء جيف أوي باستخدام ID الرسالة")
    .addStringOption(o => o.setName("message_id").setDescription("ID رسالة الجيف أوي").setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder()
    .setName("dev")
    .setDescription("معلومات مطور البوت"),

  new SlashCommandBuilder()
    .setName("encrypt")
    .setDescription("إرسال نص بصيغة مخصصة عبر Webhook باسمك وصورتك")
    .addStringOption(o => o.setName("original").setDescription("الجملة الأساسية").setMaxLength(1800).setRequired(true))
    .addStringOption(o => o.setName("encoded").setDescription("الجملة بعد الاستبدال").setMaxLength(1800).setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder()
    .setName("autoreply")
    .setDescription("إدارة الردود التلقائية")
    .addSubcommand(sc => sc.setName("add").setDescription("إضافة رد تلقائي")
      .addStringOption(o => o.setName("trigger").setDescription("الكلمة أو العبارة التي تشغل الرد").setMaxLength(100).setRequired(true))
      .addStringOption(o => o.setName("response").setDescription("الرد الذي سيرسله البوت").setMaxLength(1500).setRequired(true)))
    .addSubcommand(sc => sc.setName("remove").setDescription("حذف رد تلقائي")
      .addStringOption(o => o.setName("trigger").setDescription("الكلمة أو العبارة").setMaxLength(100).setRequired(true)))
    .addSubcommand(sc => sc.setName("list").setDescription("عرض الردود التلقائية"))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder()
    .setName("help")
    .setDescription("عرض أوامر البوت والمساعدة"),

  new SlashCommandBuilder()
    .setName("creditpanel")
    .setDescription("إرسال لوحة متجر شراء الكريدت")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder()
    .setName("broadcastpanel")
    .setDescription("نشر لوحة اشتراك استقبال الإعلانات في هذه القناة")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

  new SlashCommandBuilder()
    .setName("broadcast")
    .setDescription("إرسال إعلان للمشتركين باستقبال الرسائل")
    .addStringOption(o => o.setName("message").setDescription("نص الإعلان").setMaxLength(1800).setRequired(true))
    .addStringOption(o => o.setName("target").setDescription("الفئة المستهدفة").setRequired(true)
      .addChoices(
        { name: "كل المشتركين (متصلين وغير متصلين)", value: "all" },
        { name: "المشتركين المتصلين فقط", value: "online" },
        { name: "المشتركين ضمن رتبة محددة", value: "role" }
      ))
    .addAttachmentOption(o => o.setName("image").setDescription("صورة اختيارية للإعلان").setRequired(false))
    .addRoleOption(o => o.setName("role").setDescription("الرتبة المطلوبة عند اختيار فئة رتبة محددة").setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
].map(command => command.toJSON());

function giveawayEmbed(data) {
  const timestamp = Math.floor(data.endsAt / 1000);
  const winnersText = data.ended
    ? (data.winnersList.length ? data.winnersList.map(id => `<@${id}>`).join(", ") : "لم يتم العثور على فائزين")
    : "سيتم الإعلان عنهم بعد انتهاء الجيف أوي";

  const embed = new EmbedBuilder()
    .setColor(data.ended ? 0x747F8D : 0x8B5CF6)
    .setTitle(`🎉 ${data.title}`)
    .setDescription([
      `${CUSTOM_EMOJI} **الجائزة:** ${data.prize}`,
      "",
      `${CUSTOM_EMOJI} **وقت الانتهاء:** <t:${timestamp}:F>`,
      `${CUSTOM_EMOJI} **ينتهي:** <t:${timestamp}:R>`,
      `${CUSTOM_EMOJI} **صاحب الجيف أوي:** <@${data.host}>`,
      `${CUSTOM_EMOJI} **عدد الفائزين:** ${data.winners}`,
      `${CUSTOM_EMOJI} **عدد المشاركين:** ${data.participants.length}`,
      data.description ? `\n${data.description}` : "",
      "",
      `${CUSTOM_EMOJI} **الفائزون:** ${winnersText}`
    ].filter(Boolean).join("\n"))
    .setFooter({ text: data.ended ? "GIVEAWAY ENDED" : "GIVEAWAY • حظاً موفقاً للجميع" })
    .setTimestamp();

  return embed;
}

function publicButtons(id, data) {
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`join:${id}`)
      .setLabel(data.ended ? "انتهى الجيف أوي" : "دخول الجيف أوي")
      .setEmoji("🎉")
      .setStyle(ButtonStyle.Success)
      .setDisabled(data.ended)
  );
  return [row];
}

function privateControlButtons(id) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`random:${id}`)
        .setLabel("اختيار فائز عشوائي")
        .setEmoji("🎲")
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`specific:${id}`)
        .setLabel("اختيار شخص معين")
        .setEmoji("👤")
        .setStyle(ButtonStyle.Primary)
    )
  ];
}

async function updateGiveawayMessage(data) {
  const channel = await client.channels.fetch(data.channel);
  if (!channel || !channel.isTextBased()) throw new Error("Giveaway channel unavailable");
  const message = await channel.messages.fetch(data.message);
  await message.edit({ embeds: [giveawayEmbed(data)], components: publicButtons(data.message, data) });
}

async function finishGiveaway(messageId, selectedUserId = null) {
  const data = giveaways[messageId];
  if (!data || data.ended) return { ok: false, reason: "هذا الجيف أوي غير موجود أو منتهي." };

  let winners = [];
  if (selectedUserId) {
    if (!data.participants.includes(selectedUserId)) {
      return { ok: false, reason: "الشخص المحدد ليس من المشاركين في الجيف أوي." };
    }
    winners = [selectedUserId];
  } else {
    const pool = [...data.participants];
    const count = Math.min(data.winners, pool.length);
    for (let i = 0; i < count; i++) {
      const index = Math.floor(Math.random() * pool.length);
      winners.push(pool.splice(index, 1)[0]);
    }
  }

  data.ended = true;
  data.winnersList = winners;
  saveData();

  try {
    await updateGiveawayMessage(data);
    const channel = await client.channels.fetch(data.channel);
    const announcement = winners.length
      ? `${CUSTOM_EMOJI} **مبروك للفائزين!**\n${winners.map(id => `<@${id}>`).join(", ")}`
      : `${CUSTOM_EMOJI} انتهى الجيف أوي، ولم يشارك أحد.`;
    await channel.send({
      content: announcement,
      allowedMentions: { users: winners }
    });
    return { ok: true, winners };
  } catch (error) {
    console.error("Could not finish giveaway:", error);
    return { ok: false, reason: "تعذر تحديث رسالة الجيف أوي. تحقق من صلاحيات البوت." };
  }
}

function scheduleGiveaway(messageId) {
  const data = giveaways[messageId];
  if (!data || data.ended) return;

  const remaining = data.endsAt - Date.now();
  if (remaining <= 0) {
    finishGiveaway(messageId).catch(console.error);
    return;
  }

  setTimeout(() => scheduleGiveaway(messageId), Math.min(remaining, 2_147_000_000));
}

function isManager(interaction) {
  return interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild);
}

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(TOKEN);
  await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commandData });
  console.log("تم تسجيل أوامر السلاش.");
}

function helpEmbed(section = "all") {
  const embed = new EmbedBuilder().setColor(0x5865F2).setTitle("قائمة أوامر البوت");
  if (section === "giveaway" || section === "all") {
    embed.addFields({ name: "🎉 أوامر الجيف أوي", value:
      "`/giveaway` إنشاء جيف أوي وتحديد المدة والجائزة والفائزين\n" +
      "`/endgiveaway` إنهاء جيف أوي باستخدام ID الرسالة\n" +
      "زر دخول الجيف أوي للمشاركة، ولوحة تحكم خاصة لصاحب الجيف أوي" });
  }
  if (section === "tools" || section === "all") {
    embed.addFields({ name: "🛠️ الأوامر الإضافية", value:
      "`/encrypt` إرسال الجملة المستبدلة عبر Webhook باسمك وصورتك\n" +
      "`/autoreply add` إضافة رد تلقائي\n" +
      "`/autoreply remove` حذف رد تلقائي\n" +
      "`/autoreply list` عرض الردود التلقائية\n" +
      "`/dev` معلومات المطور\n`/creditpanel` إرسال لوحة شراء الكريدت\n`/broadcastpanel` نشر لوحة الاشتراك بالإعلانات\n`/broadcast` إرسال إعلان للمشتركين فقط\n`/help` عرض هذه القائمة" });
  }
  embed.setFooter({ text: "Wahj Bot • Developer Adam" });
  return embed;
}

function helpButtons() {
  return [new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId("help:all").setLabel("كل الأوامر").setStyle(ButtonStyle.Primary),
    new ButtonBuilder().setCustomId("help:giveaway").setLabel("الجيف أوي").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId("help:tools").setLabel("الإضافات").setStyle(ButtonStyle.Secondary)
  )];
}


// ===================== متجر شراء الكريدت والتذاكر =====================
function readTickets() {
  try {
    if (!fs.existsSync(TICKETS_FILE)) fs.writeFileSync(TICKETS_FILE, "{}");
    return JSON.parse(fs.readFileSync(TICKETS_FILE, "utf8"));
  } catch (error) {
    console.error("Could not read tickets.json:", error);
    return {};
  }
}
let tickets = readTickets();
function saveTickets() {
  fs.writeFileSync(TICKETS_FILE, JSON.stringify(tickets, null, 2));
}

const PRICE_TEXT = [
  "**السعودي 🇸🇦**\n0.74 ر.س = 90 مليون\n7.4 ر.س = 990 مليون",
  "**سوا**\n1 سوا = 100 مليون\n20 سوا = 2.0 مليار",
  "**المغربي 🇲🇦**\n1 مغربي = 40.1 مليون\n50 مغربي = 2.0 مليار",
  "**لايك كارد**\n1 لايك كارد = 90 مليون\n20 لايك كارد = 1.9 مليار",
  "**السوري 🇸🇾**\n150 ليرة = 460 مليون\n300 ليرة = 910 مليون",
  "**ريزر جولد**\n1 = 390 مليون\n5 = 1.9 مليار",
  "**كريبتو**\n1 = 500 مليون\n10 = 5.0 مليار",
  "**الأردني 🇯🇴**\n1 = 580 مليون\n10 = 5.8 مليار",
  "**آسيا**\n1 = 290 مليون\n10 = 2.9 مليار",
  "**التونسي 🇹🇳**\n1 = 140 مليون\n10 = 1.40 مليار",
  "**المصري**\n0.1 = 900 ألف\n100 = 1.9 مليون"
].join("\n\n");

const PAYMENT_METHODS = {
  saudi: { label: "برق - سعودي", unit: "ر.س", instructions: "📲 **برق — بيانات التحويل:**\nالرقم: `0532050962`\nالآيبان: `SA1230100991102511282842`\nاسم صاحب الحساب: **سلمان علي عبده صميلي**\n\nيرجى إدخال الغرض الحقيقي والصحيح للتحويل حسب طبيعة العملية.", calculate: amount => {
    if (Math.abs(amount - 0.74) < 0.000001) return { credits: 90_000_000, payable: "0.74 ر.س" };
    if (Math.abs(amount - 7.4) < 0.000001) return { credits: 990_000_000, payable: "7.4 ر.س" };
    return null;
  }, placeholder: "0.74 أو 7.4" },
  syria: { label: "شام كاش - سوري", unit: "ليرة سورية", instructions: "🇸🇾 **شام كاش — بيانات التحويل:**\nالمحفظة: `شام كاش`\nكود المحفظة: `5d8e474ec63bcb129c45c9853eaf7690`\n[عرض باركود التحويل](https://cdn.discordapp.com/attachments/1559201288057524336/1563293419596554290/WhatsApp_Image_2026-10-23_at_11.06.51_PM.jpeg)", calculate: amount => {
    if (Math.abs(amount - 150) < 0.000001) return { credits: 460_000_000, payable: "150 ليرة سورية" };
    if (Math.abs(amount - 300) < 0.000001) return { credits: 910_000_000, payable: "300 ليرة سورية" };
    return null;
  }, placeholder: "150 أو 300" },
  crypto: { label: "كريبتو - LTC", unit: "كريبتو", instructions: "🔘 **LTC — عنوان المحفظة:**\n`LLs5PcbHyjcgfZWuxnA1avokzcGe6t4xof`", calculate: amount => {
    if (!(amount > 0) || !Number.isFinite(amount)) return null;
    const usdt = amount;
    if (!(LTC_USDT_RATE > 0)) return { credits: Math.round(amount * 500_000_000), payable: `${usdt.toFixed(4)} USDT`, rateMissing: true };
    const ltc = usdt / LTC_USDT_RATE;
    return { credits: Math.round(amount * 500_000_000), payable: `${usdt.toFixed(4)} USDT (حوالي ${ltc.toFixed(8)} LTC)`, ltc };
  }, placeholder: "مثال: 2" },
  iraq: { label: "آسيا - عراقي", unit: "دينار عراقي", instructions: "🇮🇶 **تحويل آسيا — رقم التحويل:**\n`07758875938`", calculate: amount => amount > 0 ? { credits: Math.round(amount * 290_000_000), payable: `${amount} آسيا` } : null, placeholder: "مثال: 2" },
  egypt: { label: "فودافون كاش - مصري", unit: "جنيه مصري", instructions: "📱 **فودافون كاش — حوّل إلى الرقم:**\n`01013110546`", calculate: amount => {
    if (Math.abs(amount - 0.1) < 0.000001) return { credits: 900_000, payable: "0.1 جنيه مصري" };
    if (Math.abs(amount - 100) < 0.000001) return { credits: 1_900_000, payable: "100 جنيه مصري" };
    return null;
  }, placeholder: "0.1 أو 100" },
  tunisia: { label: "D17 - تونسي", unit: "دينار تونسي", instructions: "📱 **D17 — حوّل إلى الرقم:**\n`27984564`", calculate: amount => amount > 0 ? { credits: Math.round(amount * 140_000_000), payable: `${amount} تونسي` } : null, placeholder: "مثال: 2" }
};

function storePanelEmbed() {
  return new EmbedBuilder().setColor(0x5865F2)
    .setTitle("🛒 متجر Wahj?")
    .setDescription("## مرحباً بك في أفضل ستور لـ منتجات الدسكورد! ☕\n\nاضغط على الزر أدناه لبدء عملية الشراء.\nسيتم فتح تذكرة خاصة بك لإتمام طلبك بأمان وسرعة.\n\n---\n" + PRICE_TEXT + "\n\n**طرق دفع متوقفة مؤقتاً:** سوا، المغربي، لايك كارد، ريزر جولد، الأردني.\nالطرق المتاحة للاختيار هي الطرق التي تتوفر لها بيانات تحويل أعلاه.")
    .setFooter({ text: "Wahj Store • Credit Shop" });
}

async function createCreditTicket(interaction) {
  const guild = interaction.guild;
  const existing = Object.values(tickets).find(t => t.guildId === guild.id && t.userId === interaction.user.id && t.status !== "closed");
  if (existing) {
    const oldChannel = await guild.channels.fetch(existing.channelId).catch(() => null);
    if (oldChannel) return interaction.reply({ content: `لديك تذكرة مفتوحة بالفعل: ${oldChannel}`, ephemeral: true });
  }

  const overwrites = [
    { id: guild.roles.everyone.id, deny: ["ViewChannel"] },
    { id: interaction.user.id, allow: ["ViewChannel", "SendMessages", "ReadMessageHistory", "AttachFiles"] },
    { id: client.user.id, allow: ["ViewChannel", "SendMessages", "ReadMessageHistory", "ManageChannels", "AttachFiles", "EmbedLinks"] }
  ];
  if (STAFF_ROLE_ID && guild.roles.cache.has(STAFF_ROLE_ID)) {
    overwrites.push({ id: STAFF_ROLE_ID, allow: ["ViewChannel", "SendMessages", "ReadMessageHistory", "AttachFiles"] });
  }

  const channel = await guild.channels.create({
    name: `شراء-كريدت-${interaction.user.username}`.toLowerCase().replace(/[^\p{L}\p{N}-]/gu, "-").slice(0, 90),
    type: ChannelType.GuildText,
    parent: TICKET_CATEGORY_ID || undefined,
    permissionOverwrites: overwrites,
    topic: `Credit purchase ticket for ${interaction.user.id}`
  });

  tickets[channel.id] = { guildId: guild.id, channelId: channel.id, userId: interaction.user.id, status: "open", createdAt: Date.now() };
  saveTickets();

  const paymentSelect = new StringSelectMenuBuilder()
    .setCustomId(`paymethod:${channel.id}`)
    .setPlaceholder("اختر طريقة الدفع")
    .addOptions(Object.entries(PAYMENT_METHODS).map(([value, method]) => ({ label: method.label, value })));
  const closeRow = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ticketclose:${channel.id}`).setLabel("إغلاق التذكرة").setEmoji("🔒").setStyle(ButtonStyle.Danger)
  );

  const embed = new EmbedBuilder().setColor(0x5865F2).setTitle("💳 اختر طريقة الدفع")
    .setDescription(`أهلاً بك ${interaction.user} 👋\nاختر طريقة الدفع المناسبة:\n\n${PRICE_TEXT}\n\n**الخيارات التي لا تظهر في القائمة متوقفة مؤقتاً.**`);
  await channel.send({ content: `${interaction.user}`, embeds: [embed], components: [new ActionRowBuilder().addComponents(paymentSelect), closeRow], allowedMentions: { users: [interaction.user.id] } });
  return interaction.reply({ content: `تم فتح تذكرتك: ${channel}`, ephemeral: true });
}

function transferEmbed(ticket, methodKey, quote) {
  const method = PAYMENT_METHODS[methodKey];
  const note = quote.rateMissing ? "\n\n⚠️ **لم يتم ضبط سعر LTC مقابل USDT بعد. لا تحول قبل أن يضبطه مالك البوت في ملف .env.**" : "";
  return new EmbedBuilder().setColor(0xF1C40F).setTitle("💸 تفاصيل التحويل")
    .setDescription(`حوّل المبلغ إلى:\n\n${method.instructions}\n\nبعد التحويل اضغط **تم التحويل** ثم أرسل صورة الإيصال في هذه التذكرة.\n\n📦 **الكمية المطلوبة**\n**${quote.credits.toLocaleString("en-US")} Probot Credits**\n\n💰 **المبلغ المطلوب**\n**${quote.payable}**${note}`)
    .setFooter({ text: "لا تعتمد على صورة الإيصال وحدها؛ يتم التحقق من وصول المبلغ فعلياً." });
}

async function forwardPaymentProof(message, ticket, attachment) {
  const proofChannel = await client.channels.fetch(PAYMENT_PROOF_CHANNEL_ID).catch(() => null);
  if (!proofChannel || !proofChannel.isTextBased()) {
    await message.reply("روم مراجعة الإيصالات غير متاح. تواصل مع الإدارة.");
    return;
  }
  const method = PAYMENT_METHODS[ticket.paymentMethod];
  const embed = new EmbedBuilder().setColor(0xF1C40F).setTitle("🧾 إيصال تحويل جديد")
    .setDescription(`**العضو:** <@${ticket.userId}>\n**التذكرة:** <#${ticket.channelId}>\n**طريقة الدفع:** ${method ? method.label : "غير محددة"}\n**المبلغ:** ${ticket.payable || "غير مسجل"}\n**الكمية:** ${ticket.credits ? ticket.credits.toLocaleString("en-US") : "غير مسجلة"} Probot Credits\n\n**الحالة:** بانتظار مراجعة الإدارة`)
    .setImage(attachment.url).setTimestamp();
  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`paymentok:${ticket.channelId}`).setLabel("وصل المبلغ").setEmoji("✅").setStyle(ButtonStyle.Success),
    new ButtonBuilder().setCustomId(`paymentno:${ticket.channelId}`).setLabel("لم يصل المبلغ").setEmoji("❌").setStyle(ButtonStyle.Danger)
  );
  await proofChannel.send({ embeds: [embed], components: [row], allowedMentions: { parse: [] } });
  ticket.status = "proof_submitted";
  saveTickets();
  await message.reply("تم إرسال الإيصال للإدارة للمراجعة. يرجى انتظار التأكيد.");
}

client.once("ready", () => {
  const startedAt = new Date().toLocaleString("en-GB", { timeZone: "Asia/Hebron" });
  console.log("\\n╔══════════════════════════════════════════════╗");
  console.log("║              WAHJ DISCORD BOT                ║");
  console.log("╠══════════════════════════════════════════════╣");
  console.log(`║ الحالة       : ONLINE • يعمل الآن            ║`);
  console.log(`║ التشغيل      : 24H READY                     ║`);
  console.log(`║ اسم البوت    : ${client.user.tag}`.padEnd(47) + "║");
  console.log("║ المطوّر      : Adam                          ║");
  console.log(`║ وقت التشغيل  : ${startedAt}`.padEnd(47) + "║");
  console.log("╚══════════════════════════════════════════════╝\\n");
  for (const id of Object.keys(giveaways)) scheduleGiveaway(id);
});

client.on("interactionCreate", async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === "giveaway") {
        if (!isManager(interaction)) {
          return interaction.reply({ content: "ليس لديك صلاحية استخدام هذا الأمر.", ephemeral: true });
        }

        const duration = parseDuration(interaction.options.getString("duration"));
        if (!duration) {
          return interaction.reply({ content: "المدة غير صحيحة. استخدم 10m أو 2h أو 1d (الحد الأقصى 30 يوم).", ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const data = {
          guild: interaction.guildId,
          channel: interaction.channelId,
          host: interaction.user.id,
          prize: interaction.options.getString("prize"),
          winners: interaction.options.getInteger("winners"),
          title: interaction.options.getString("title"),
          description: interaction.options.getString("description") || "",
          endsAt: Date.now() + duration,
          participants: [],
          ended: false,
          winnersList: []
        };

        const message = await interaction.channel.send({
          content: "||@everyone | @here||",
          embeds: [giveawayEmbed(data)],
          allowedMentions: { parse: ["everyone"] }
        });

        data.message = message.id;
        giveaways[message.id] = data;
        saveData();

        await message.edit({
          embeds: [giveawayEmbed(data)],
          components: publicButtons(message.id, data)
        });

        await interaction.editReply({
          content: `تم إنشاء الجيف أوي بنجاح!\nID الرسالة: \`${message.id}\``,
          components: privateControlButtons(message.id)
        });

        scheduleGiveaway(message.id);
        return;
      }

      if (interaction.commandName === "endgiveaway") {
        if (!isManager(interaction)) {
          return interaction.reply({ content: "ليس لديك صلاحية استخدام هذا الأمر.", ephemeral: true });
        }
        await interaction.deferReply({ ephemeral: true });
        const id = interaction.options.getString("message_id").trim();
        const result = await finishGiveaway(id);
        return interaction.editReply({ content: result.ok ? "تم إنهاء الجيف أوي وإعلان الفائزين." : result.reason });
      }

      if (interaction.commandName === "encrypt") {
        if (!isManager(interaction)) {
          return interaction.reply({ content: "ليس لديك صلاحية استخدام هذا الأمر.", ephemeral: true });
        }
        const original = interaction.options.getString("original");
        const encoded = interaction.options.getString("encoded");
        if (original === encoded) {
          return interaction.reply({ content: "الجملة بعد الاستبدال مطابقة للأصلية. أدخل النص المعدّل.", ephemeral: true });
        }
        if (!interaction.channel || !interaction.channel.isTextBased() || !interaction.channel.createWebhook) {
          return interaction.reply({ content: "لا يمكن إنشاء Webhook في هذه القناة.", ephemeral: true });
        }
        await interaction.deferReply({ ephemeral: true });
        let webhook;
        try {
          webhook = await interaction.channel.createWebhook({
            name: interaction.user.username,
            avatar: interaction.user.displayAvatarURL({ extension: "png", size: 256 })
          });
          await webhook.send({
            content: encoded,
            username: interaction.user.username,
            avatarURL: interaction.user.displayAvatarURL({ extension: "png", size: 256 }),
            allowedMentions: { parse: [] }
          });
          await webhook.delete("تم إرسال النص المطلوب").catch(() => {});
          return interaction.editReply({ content: "تم إرسال النص عبر Webhook باسمك وصورتك. ملاحظة: هذا استبدال نصي وليس تشفيراً أمنياً." });
        } catch (error) {
          console.error("Webhook send failed:", error);
          if (webhook) await webhook.delete().catch(() => {});
          return interaction.editReply({ content: "تعذر الإرسال. تأكد أن البوت يملك صلاحية Manage Webhooks في هذه القناة." });
        }
      }

      if (interaction.commandName === "autoreply") {
        if (!isManager(interaction)) {
          return interaction.reply({ content: "ليس لديك صلاحية استخدام هذا الأمر.", ephemeral: true });
        }
        const sub = interaction.options.getSubcommand();
        if (sub === "add") {
          const trigger = interaction.options.getString("trigger").trim();
          const response = interaction.options.getString("response").trim();
          const existing = settings.autoReplies.findIndex(item => item.trigger.toLowerCase() === trigger.toLowerCase());
          if (existing >= 0) settings.autoReplies[existing] = { trigger, response };
          else settings.autoReplies.push({ trigger, response });
          saveSettings();
          return interaction.reply({ content: `تم حفظ الرد التلقائي للكلمة: **${trigger}**`, ephemeral: true });
        }
        if (sub === "remove") {
          const trigger = interaction.options.getString("trigger").trim();
          const before = settings.autoReplies.length;
          settings.autoReplies = settings.autoReplies.filter(item => item.trigger.toLowerCase() !== trigger.toLowerCase());
          saveSettings();
          return interaction.reply({ content: before === settings.autoReplies.length ? "لم أجد هذه الكلمة." : `تم حذف الرد الخاص بـ **${trigger}**.`, ephemeral: true });
        }
        if (sub === "list") {
          const list = settings.autoReplies.length
            ? settings.autoReplies.map((item, i) => `**${i + 1}. ${item.trigger}** ← ${item.response}`).join("\n").slice(0, 3900)
            : "لا توجد ردود تلقائية محفوظة حالياً.";
          return interaction.reply({ embeds: [new EmbedBuilder().setColor(0x5865F2).setTitle("الردود التلقائية").setDescription(list)], ephemeral: true });
        }
      }

      if (interaction.commandName === "creditpanel") {
        if (!isManager(interaction)) return interaction.reply({ content: "ليس لديك صلاحية استخدام هذا الأمر.", ephemeral: true });
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId("creditpanel:buy").setLabel("شراء كريدت").setEmoji("🛒").setStyle(ButtonStyle.Success)
        );
        const panelChannel = await interaction.guild.channels.fetch(CREDIT_PANEL_CHANNEL_ID).catch(() => null);
        if (!panelChannel || !panelChannel.isTextBased()) {
          return interaction.reply({ content: "تعذر العثور على روم لوحة شراء الكريدت. تأكد من ID وصلاحيات البوت.", ephemeral: true });
        }
        await panelChannel.send({ embeds: [storePanelEmbed()], components: [row] });
        return interaction.reply({ content: `تم إرسال لوحة شراء الكريدت في <#${CREDIT_PANEL_CHANNEL_ID}>.`, ephemeral: true });
      }

      if (interaction.commandName === "broadcastpanel") {
        if (!isManager(interaction)) return interaction.reply({ content: "ليس لديك صلاحية استخدام هذا الأمر.", ephemeral: true });
        const embed = new EmbedBuilder().setColor(0x5865F2).setTitle("📢 الاشتراك في الإعلانات")
          .setDescription("اضغط **السماح باستقبال الرسائل** إذا كنت ترغب باستلام إعلانات السيرفر على الخاص. يمكنك إلغاء الاشتراك بأي وقت، ولن تصلك إعلانات بعد الإلغاء.");
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`broadcast:subscribe:${interaction.guildId}`).setLabel("السماح باستقبال الرسائل").setEmoji("✅").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`broadcast:unsubscribe:${interaction.guildId}`).setLabel("إلغاء استقبال الرسائل").setEmoji("🔕").setStyle(ButtonStyle.Secondary)
        );
        await interaction.channel.send({ embeds: [embed], components: [row] });
        return interaction.reply({ content: "تم نشر لوحة الاشتراك في هذه القناة.", ephemeral: true });
      }

      if (interaction.commandName === "broadcast") {
        if (!isManager(interaction)) return interaction.reply({ content: "ليس لديك صلاحية استخدام هذا الأمر.", ephemeral: true });
        const targetType = interaction.options.getString("target");
        const role = interaction.options.getRole("role");
        if (targetType === "role" && !role) return interaction.reply({ content: "عند اختيار رتبة محددة، يجب تحديد خيار role أيضاً.", ephemeral: true });
        if (targetType !== "role" && role) return interaction.reply({ content: "احذف خيار role أو اختر فئة الرتبة المحددة.", ephemeral: true });
        await interaction.deferReply({ ephemeral: true });
        const guild = interaction.guild;
        let members;
        try {
          members = await guild.members.fetch();
        } catch (error) {
          console.error("Could not fetch guild members for broadcast:", error);
          return interaction.editReply("تعذر جلب أعضاء السيرفر. فعّل Server Members Intent من Discord Developer Portal وتأكد من صلاحيات البوت.");
        }
        const subscribers = broadcastData.subscribers[guild.id] || [];
        const recipients = members.filter(member =>
          !member.user.bot && subscribers.includes(member.id) &&
          (targetType !== "online" || ["online", "idle", "dnd"].includes(member.presence?.status)) &&
          (targetType !== "role" || member.roles.cache.has(role.id))
        );
        if (!recipients.size) return interaction.editReply("لا يوجد أعضاء مشتركين يطابقون الفئة المحددة.");

        const text = interaction.options.getString("message");
        const image = interaction.options.getAttachment("image");
        const embed = new EmbedBuilder().setColor(0x5865F2).setDescription(text).setFooter({ text: `إعلانات ${guild.name}` }).setTimestamp();
        if (image && (image.contentType?.startsWith("image/") || /\.(png|jpe?g|gif|webp|avif)(\?|$)/i.test(image.url))) embed.setImage(image.url);
        else if (image) return interaction.editReply("الملف المرفق ليس صورة صالحة.");
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId(`broadcast:subscribe:${guild.id}`).setLabel("السماح باستقبال الرسائل").setEmoji("✅").setStyle(ButtonStyle.Success),
          new ButtonBuilder().setCustomId(`broadcast:unsubscribe:${guild.id}`).setLabel("عدم إرسال هذه الرسائل مرة أخرى").setEmoji("🔕").setStyle(ButtonStyle.Danger)
        );

        let sent = 0, failed = 0, skipped = 0;
        for (const member of recipients.values()) {
          // Re-check opt-in immediately before each DM so an opt-out is respected.
          if (!isBroadcastSubscriber(guild.id, member.id)) { skipped++; continue; }
          try {
            await member.send({ embeds: [embed], components: [row] });
            sent++;
          } catch (error) {
            failed++;
          }
          // Deliberately paced; Discord rate limits are respected rather than bypassed with extra tokens.
          await sleep(1200);
        }
        return interaction.editReply(`انتهى الإرسال.
✅ تم الإرسال: **${sent}**
❌ تعذر الإرسال (خاص مغلق/خطأ): **${failed}**
⏭️ تم تخطيهم بعد إلغاء الاشتراك: **${skipped}**

ملاحظة: الإرسال للمشتركين فقط، وقد يستغرق وقتاً حسب عددهم.`);
      }

      if (interaction.commandName === "help") {
        return interaction.reply({ embeds: [helpEmbed("all")], components: helpButtons(), ephemeral: true });
      }

      if (interaction.commandName === "dev") {
        const embed = new EmbedBuilder()
          .setColor(0x8B5CF6)
          .setTitle("👨‍💻 معلومات المطور")
          .setDescription(`تم تطوير هذا البوت بعناية واهتمام.\n\n**مطور البوت:** آدم (Adam)\n\n${CUSTOM_EMOJI} شكراً لاستخدامك Wahj Bot!`)
          .setThumbnail(client.user.displayAvatarURL())
          .setFooter({ text: "Wahj Bot • Developer Adam" });
        return interaction.reply({ embeds: [embed] });
      }
    }

    if (interaction.isStringSelectMenu() && interaction.customId.startsWith("paymethod:")) {
      const channelId = interaction.customId.split(":")[1];
      const ticket = tickets[channelId];
      if (!ticket || ticket.userId !== interaction.user.id || ticket.status === "closed") return interaction.reply({ content: "هذه التذكرة ليست لك أو أنها مغلقة.", ephemeral: true });
      const methodKey = interaction.values[0];
      const modal = new ModalBuilder().setCustomId(`payamount:${channelId}:${methodKey}`).setTitle("تحديد مبلغ الشراء");
      const amountInput = new TextInputBuilder().setCustomId("amount").setLabel("أدخل المبلغ حسب طريقة الدفع المختارة").setPlaceholder(PAYMENT_METHODS[methodKey].placeholder).setStyle(TextInputStyle.Short).setRequired(true);
      modal.addComponents(new ActionRowBuilder().addComponents(amountInput));
      return interaction.showModal(modal);
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("payamount:")) {
      const [, channelId, methodKey] = interaction.customId.split(":");
      const ticket = tickets[channelId];
      if (!ticket || ticket.userId !== interaction.user.id || ticket.status === "closed") return interaction.reply({ content: "التذكرة غير متاحة.", ephemeral: true });
      const amount = Number(interaction.fields.getTextInputValue("amount").trim().replace(",", "."));
      const quote = PAYMENT_METHODS[methodKey]?.calculate(amount);
      if (!quote) return interaction.reply({ content: "المبلغ غير صحيح أو غير موجود ضمن الباقات المحددة. راجع الأسعار وأعد المحاولة.", ephemeral: true });
      if (quote.rateMissing) return interaction.reply({ content: "الدفع عبر LTC متوقف مؤقتاً حتى يتم ضبط سعر LTC مقابل USDT في ملف .env. لا تحول الآن.", ephemeral: true });
      ticket.paymentMethod = methodKey;
      ticket.credits = quote.credits;
      ticket.payable = quote.payable;
      ticket.status = "awaiting_payment";
      saveTickets();
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`paid:${channelId}`).setLabel("تم التحويل").setEmoji("📤").setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`ticketclose:${channelId}`).setLabel("إغلاق التذكرة").setEmoji("🔒").setStyle(ButtonStyle.Danger)
      );
      const channel = await client.channels.fetch(channelId);
      await channel.send({ embeds: [transferEmbed(ticket, methodKey, quote)], components: [row] });
      return interaction.reply({ content: "تم تجهيز تفاصيل الدفع داخل التذكرة.", ephemeral: true });
    }

    if (interaction.isButton()) {
      if (interaction.customId.startsWith("broadcast:")) {
        const [, action, guildId] = interaction.customId.split(":");
        if (!guildId) return interaction.reply({ content: "تعذر تحديد السيرفر المرتبط بهذا الاشتراك.", ephemeral: Boolean(interaction.guildId) });
        if (action === "subscribe") {
          setBroadcastSubscription(guildId, interaction.user.id, true);
          return interaction.reply({ content: "✅ تم تفعيل استقبال الإعلانات. يمكنك إلغاء الاشتراك في أي وقت من زر إلغاء الاستقبال.", ephemeral: Boolean(interaction.guildId) });
        }
        if (action === "unsubscribe") {
          setBroadcastSubscription(guildId, interaction.user.id, false);
          return interaction.reply({ content: "🔕 تم إلغاء اشتراكك. لن يرسل لك البوت إعلانات أخرى من هذا السيرفر.", ephemeral: Boolean(interaction.guildId) });
        }
      }
      if (interaction.customId === "creditpanel:buy") return createCreditTicket(interaction);
      if (interaction.customId.startsWith("help:")) {
        const section = interaction.customId.split(":")[1];
        return interaction.update({ embeds: [helpEmbed(section)], components: helpButtons() });
      }
      if (interaction.customId.startsWith("ticketclose:")) {
        const channelId = interaction.customId.split(":")[1];
        const ticket = tickets[channelId];
        if (!ticket || (interaction.user.id !== ticket.userId && !isManager(interaction))) return interaction.reply({ content: "لا تملك صلاحية إغلاق هذه التذكرة.", ephemeral: true });
        await interaction.reply({ content: "سيتم إغلاق التذكرة خلال لحظات.", ephemeral: true });
        ticket.status = "closed";
        saveTickets();
        setTimeout(() => interaction.channel?.delete("Ticket closed").catch(() => {}), 2500);
        return;
      }
      if (interaction.customId.startsWith("paid:")) {
        const channelId = interaction.customId.split(":")[1];
        const ticket = tickets[channelId];
        if (!ticket || ticket.userId !== interaction.user.id || ticket.status === "closed") return interaction.reply({ content: "هذه التذكرة ليست لك أو أنها مغلقة.", ephemeral: true });
        ticket.status = "awaiting_proof";
        saveTickets();
        return interaction.reply({ content: "أرسل الآن صورة واضحة لإيصال التحويل في هذه التذكرة. لا ترسل بيانات سرية إضافية غير لازمة.", ephemeral: true });
      }
      if (interaction.customId.startsWith("paymentok:") || interaction.customId.startsWith("paymentno:")) {
        if (!isManager(interaction)) return interaction.reply({ content: "هذا الزر مخصص للإدارة فقط.", ephemeral: true });
        const [decision, channelId] = interaction.customId.split(":");
        const ticket = tickets[channelId];
        if (!ticket) return interaction.reply({ content: "بيانات التذكرة غير موجودة.", ephemeral: true });
        const target = await client.channels.fetch(channelId).catch(() => null);
        if (decision === "paymentok") {
          ticket.status = "payment_confirmed_waiting_delivery";
          saveTickets();
          if (target) await target.send({ content: `✅ <@${ticket.userId}> **تم تأكيد وصول التحويل، والطلب الآن بانتظار التسليم.**`, allowedMentions: { users: [ticket.userId] } });
          await interaction.update({ content: "تم تسجيل أن المبلغ وصل. تأكدت الإدارة يدوياً من الحساب/المحفظة.", components: [] });
        } else {
          ticket.status = "payment_not_received";
          saveTickets();
          if (target) await target.send({ content: `❌ <@${ticket.userId}> **لم يتم تأكيد وصول المبلغ حتى الآن. يرجى مراجعة التحويل مع الإدارة.**`, allowedMentions: { users: [ticket.userId] } });
          await interaction.update({ content: "تم تسجيل أن المبلغ لم يصل/لم يتم التحقق منه.", components: [] });
        }
        return;
      }

      const [action, messageId] = interaction.customId.split(":");
      const data = giveaways[messageId];
      if (!data) return interaction.reply({ content: "الجيف أوي غير موجود.", ephemeral: true });

      if (action === "join") {
        if (data.ended) return interaction.reply({ content: "انتهى هذا الجيف أوي.", ephemeral: true });
        if (interaction.user.bot) return interaction.reply({ content: "البوتات لا يمكنها المشاركة.", ephemeral: true });
        if (data.participants.includes(interaction.user.id)) {
          return interaction.reply({ content: "أنت مشارك بالفعل في هذا الجيف أوي.", ephemeral: true });
        }
        data.participants.push(interaction.user.id);
        saveData();
        await interaction.reply({ content: "تم تسجيل مشاركتك بنجاح! بالتوفيق 🎉", ephemeral: true });
        await updateGiveawayMessage(data);
        return;
      }

      if (action === "random" || action === "specific") {
        if (interaction.user.id !== data.host) {
          return interaction.reply({ content: "لوحة التحكم خاصة بصاحب الجيف أوي فقط.", ephemeral: true });
        }
        if (data.ended) return interaction.reply({ content: "هذا الجيف أوي منتهي بالفعل.", ephemeral: true });

        if (action === "random") {
          await interaction.deferReply({ ephemeral: true });
          const result = await finishGiveaway(messageId);
          return interaction.editReply({ content: result.ok ? "تم اختيار الفائزين وإنهاء الجيف أوي." : result.reason });
        }

        const modal = new ModalBuilder()
          .setCustomId(`winner:${messageId}`)
          .setTitle("اختيار فائز محدد");
        const input = new TextInputBuilder()
          .setCustomId("user_id")
          .setLabel("منشن الشخص أو أدخل ID")
          .setPlaceholder("@User أو 123456789012345678")
          .setStyle(TextInputStyle.Short)
          .setRequired(true);
        modal.addComponents(new ActionRowBuilder().addComponents(input));
        return interaction.showModal(modal);
      }
    }

    if (interaction.isModalSubmit() && interaction.customId.startsWith("winner:")) {
      const messageId = interaction.customId.split(":")[1];
      const data = giveaways[messageId];
      if (!data || interaction.user.id !== data.host || data.ended) {
        return interaction.reply({ content: "لا يمكن تنفيذ هذا الاختيار.", ephemeral: true });
      }

      const raw = interaction.fields.getTextInputValue("user_id").trim();
      const match = /^<@!?(\d+)>$/.exec(raw) || /^(\d+)$/.exec(raw);
      if (!match) return interaction.reply({ content: "المنشن أو ID غير صحيح.", ephemeral: true });

      await interaction.deferReply({ ephemeral: true });
      const result = await finishGiveaway(messageId, match[1]);
      return interaction.editReply({ content: result.ok ? "تم اختيار الشخص المحدد وإنهاء الجيف أوي." : result.reason });
    }
  } catch (error) {
    console.error(error);
    const message = "حدث خطأ أثناء تنفيذ الأمر. تحقق من صلاحيات البوت والسجلات.";
    if (interaction.isRepliable()) {
      if (interaction.deferred || interaction.replied) {
        await interaction.followUp({ content: message, ephemeral: true }).catch(() => {});
      } else {
        await interaction.reply({ content: message, ephemeral: true }).catch(() => {});
      }
    }
  }
});

client.on("messageCreate", async message => {
  try {
    if (!message.guild || message.author.bot) return;

    const ticket = tickets[message.channelId];
    if (ticket && ticket.userId === message.author.id && ticket.status === "awaiting_proof") {
      const proof = [...message.attachments.values()].find(att =>
        (att.contentType && att.contentType.startsWith("image/")) || /\.(png|jpe?g|gif|webp|bmp|avif)(\?|$)/i.test(att.url)
      );
      if (proof) {
        await forwardPaymentProof(message, ticket, proof);
        return;
      }
      if (message.content.trim()) {
        await message.reply("بعد الضغط على تم التحويل، أرسل صورة الإيصال كمرفق صورة حتى تصل للإدارة للمراجعة.");
        return;
      }
    }

    // في روم الصور المحدد: أرسل رابط كل صورة مرفقة تلقائياً.
    if (message.channelId === IMAGE_CHANNEL_ID) {
      const imageAttachments = [...message.attachments.values()].filter(att =>
        (att.contentType && att.contentType.startsWith("image/")) ||
        /\.(png|jpe?g|gif|webp|bmp|avif)(\?|$)/i.test(att.url)
      );
      if (imageAttachments.length) {
        const links = imageAttachments.map((att, i) => `${i + 1}. ${att.url}`).join("\n");
        await message.reply({ content: `رابط الصورة:\n${links}`, allowedMentions: { repliedUser: false } });
      } else if (message.content.trim().toLowerCase() === "رسلت صورة" || message.content.trim().toLowerCase() === "رسلت صوره") {
        await message.reply({ content: "أرفق الصورة مع رسالتك حتى أستطيع إرسال رابطها.", allowedMentions: { repliedUser: false } });
      }
    }

    // الردود التلقائية: تطابق العبارة داخل رسالة العضو.
    const content = message.content.trim().toLowerCase();
    if (!content) return;
    const matched = settings.autoReplies.find(item => content.includes(item.trigger.toLowerCase()));
    if (matched) {
      await message.reply({ content: matched.response, allowedMentions: { parse: [] } });
    }
  } catch (error) {
    console.error("messageCreate error:", error);
  }
});

(async () => {
  try {
    await registerCommands();
    await client.login(TOKEN);
  } catch (error) {
    console.error("Startup error:", error);
    process.exit(1);
  }
})();
